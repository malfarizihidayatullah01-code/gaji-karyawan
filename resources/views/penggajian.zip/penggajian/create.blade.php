@extends('layouts.app')

@section('content')

</head>
<body>

<div class="container mt-5">

    <!-- Judul -->
    <h1 class="mb-4">
        Tambah Penggajian
    </h1>

    <!-- Error validasi -->
    @if ($errors->any())

        <div class="alert alert-danger">

            <ul>

                @foreach ($errors->all() as $error)

                    <li>{{ $error }}</li>

                @endforeach

            </ul>

        </div>

    @endif

    <!-- Form -->
    <form
        action="/penggajian"
        method="POST"
    >

        @csrf

        <!-- Karyawan -->
        <div class="mb-3">

            <label class="form-label">
                Karyawan
            </label>

            <select
                name="karyawan_id"
                id="karyawan_id"
                class="form-control"
            >

                <option value="">
                    -- Pilih Karyawan --
                </option>

                @foreach($karyawans as $karyawan)

                    <option value="{{ $karyawan->id }}">

                        {{ $karyawan->nama_karyawan }}

                        -

                        {{ $karyawan->jabatan->nama_jabatan }}

                    </option>

                @endforeach

            </select>

        </div>

        <!-- Bulan -->
        <div class="mb-3">

            <label class="form-label">
                Bulan
            </label>

            <input
                type="month"
                name="bulan"
                class="form-control"
            >

        </div>

        <!-- Gaji Pokok -->
        <div class="mb-3">

            <label class="form-label">
                Gaji Pokok
            </label>

            <input
                type="text"
                id="gaji_pokok"
                class="form-control"
                readonly
            >

        </div>

        <!-- Tunjangan -->
        <div class="mb-3">

            <label class="form-label">
                Tunjangan
            </label>

            <input
                type="text"
                id="tunjangan"
                class="form-control"
                readonly
            >

        </div>

        <!-- Jam lembur -->
        <div class="mb-3">

            <label class="form-label">
                Jam Lembur
            </label>

            <input
                type="number"
                name="jam_lembur"
                id="jam_lembur"
                class="form-control"
                value="0"
            >

        </div>

        <!-- Uang lembur -->
        <div class="mb-3">

            <label class="form-label">
                Uang Lembur
            </label>

            <input
                type="text"
                id="uang_lembur"
                class="form-control"
                value="0"
                readonly
            >

        </div>

        <!-- Potongan -->
        <div class="mb-3">

            <label class="form-label">
                Potongan
            </label>

            <input
                type="text"
                id="potongan"
                class="form-control"
                value="0"
                readonly
            >

        </div>

        <!-- Total gaji -->
        <div class="mb-3">

            <label class="form-label">
                Total Gaji
            </label>

            <input
                type="text"
                id="total_gaji"
                class="form-control"
                value="0"
                readonly
            >

        </div>

        <!-- Tombol -->
        <button
            type="submit"
            class="btn btn-primary"
        >
            Simpan
        </button>

        <a
            href="/penggajian"
            class="btn btn-secondary"
        >
            Kembali
        </a>

    </form>

</div>

<!-- AJAX + JavaScript -->
<script>

    /**
     * Ketika pilih karyawan
     */
    $('#karyawan_id').change(function(){

        // Ambil ID karyawan
        let id = $(this).val();

        /**
         * IF ELSE jika kosong
         */
        if(id == ''){

            // Kosongkan field
            $('#gaji_pokok').val(0);
            $('#tunjangan').val(0);
            $('#potongan').val(0);
            $('#uang_lembur').val(0);
            $('#total_gaji').val(0);

        }else{

            /**
             * AJAX ambil data gaji
             */
            $.ajax({

                url: '/get-gaji/' + id,

                type: 'GET',

                success: function(response){

                    // Isi gaji pokok
                    $('#gaji_pokok')
                        .val(response.gaji_pokok);

                    // Isi tunjangan
                    $('#tunjangan')
                        .val(response.tunjangan);

                    // Isi potongan
                    $('#potongan')
                        .val(response.potongan);

                    // Default lembur
                    let uang_lembur = 0;

                    // Tampilkan uang lembur
                    $('#uang_lembur')
                        .val(uang_lembur);

                    // Hitung total
                    let total =
                        parseInt(response.gaji_pokok)
                        +
                        parseInt(response.tunjangan)
                        +
                        parseInt(uang_lembur)
                        -
                        parseInt(response.potongan);

                    // Tampilkan total
                    $('#total_gaji')
                        .val(total);
                }
            });

        }

    });

    /**
     * Ketika jam lembur berubah
     */
    $('#jam_lembur').keyup(function(){

        // Ambil jam lembur
        let jam =
            parseInt($(this).val()) || 0;

        // Default uang lembur
        let uang_lembur = 0;

        /**
         * IF ELSE lembur
         */
        if(jam > 0){

            uang_lembur =
                jam * 50000;

        }else{

            uang_lembur = 0;
        }

        // Tampilkan uang lembur
        $('#uang_lembur')
            .val(uang_lembur);

        // Ambil data
        let gaji_pokok =
            parseInt($('#gaji_pokok').val()) || 0;

        let tunjangan =
            parseInt($('#tunjangan').val()) || 0;

        let potongan =
            parseInt($('#potongan').val()) || 0;

        // Hitung total gaji
        let total =
            gaji_pokok
            +
            tunjangan
            +
            uang_lembur
            -
            potongan;

        // Tampilkan total
        $('#total_gaji')
            .val(total);

    });

</script>
@endsection