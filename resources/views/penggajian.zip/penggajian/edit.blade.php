@extends('layouts.app')

@section('content')

<h3 class="mb-4 fw-bold">
    Edit Penggajian
</h3>

<div class="card shadow-sm border-0">

    <div class="card-body">

        <form
            action="/penggajian/{{ $penggajian->id }}"
            method="POST"
        >

            @csrf
            @method('PUT')

            <!-- Karyawan -->
            <div class="mb-3">

                <label>Karyawan</label>

                <select
                    name="karyawan_id"
                    class="form-control"
                >

                    @foreach($karyawans as $k)

                        <option
                            value="{{ $k->id }}"
                            @selected(
                                $k->id ==
                                $penggajian->karyawan_id
                            )
                        >

                            {{ $k->nama_karyawan }}

                        </option>

                    @endforeach

                </select>

            </div>

            <!-- Bulan -->
            <div class="mb-3">

                <label>Bulan</label>

                <input
                    type="month"
                    name="bulan"
                    class="form-control"
                    value="{{ $penggajian->bulan }}"
                >

            </div>

            <!-- Jam lembur -->
            <div class="mb-3">

                <label>Jam Lembur</label>

                <input
                    type="number"
                    id="jam_lembur"
                    name="jam_lembur"
                    class="form-control"
                    value="{{ $penggajian->jam_lembur }}"
                >

            </div>

            <!-- Total -->
            <div class="mb-3">

                <label>Total Gaji</label>

                <input
                    type="text"
                    id="total_gaji"
                    class="form-control"
                    value="{{ $penggajian->total_gaji }}"
                    readonly
                >

            </div>

            <button class="btn btn-success">
                Update
            </button>

            <a
                href="/penggajian"
                class="btn btn-secondary"
            >
                Kembali
            </a>

        </form>

    </div>

</div>

<script>

const gaji =
    "{{ $penggajian->karyawan->jabatan->gaji_pokok }}";

const tunjangan =
    "{{ $penggajian->karyawan->jabatan->tunjangan }}";

$('#jam_lembur').keyup(function(){

    let jam =
        parseInt($(this).val()) || 0;

    let total =
        parseInt(gaji)
        +
        parseInt(tunjangan)
        +
        (jam * 50000);

    $('#total_gaji').val(total);

});

</script>

@endsection