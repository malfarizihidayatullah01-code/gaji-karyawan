@extends('layouts.app')

@section('content')

<div class="container-fluid">

    <div class="d-flex justify-content-between mb-3">

        <h3 class="text-primary">
            Data Penggajian
        </h3>

        <a
            href="/penggajian/create"
            class="btn btn-primary"
        >
            Tambah Penggajian
        </a>

    </div>

    @if(session('success'))

        <div class="alert alert-success">

            {{ session('success') }}

        </div>

    @endif

    <div class="card">

        <div class="card-body">

            <table class="table table-hover">

                <thead class="table-primary">

                    <tr>

                        <th>No</th>
                        <th>Nama</th>
                        <th>Jabatan</th>
                        <th>Bulan</th>
                        <th>Jam Lembur</th>
                        <th>Uang Lembur</th>
                        <th>Potongan</th>
                        <th>Total Gaji</th>
                        <th>Status</th>
                        <th>Aksi</th>

                    </tr>

                </thead>

                <tbody>

                    @forelse($penggajians as $penggajian)

                    <tr>

                        <td>
                            {{ $loop->iteration }}
                        </td>

                        <td>
                            {{ $penggajian->karyawan->nama_karyawan }}
                        </td>

                        <td>
                            {{ $penggajian->karyawan->jabatan->nama_jabatan }}
                        </td>

                        <td>
                            {{ $penggajian->bulan }}
                        </td>

                        <td>
                            {{ $penggajian->jam_lembur }} Jam
                        </td>

                        <td>
                            Rp {{ number_format($penggajian->uang_lembur,0,',','.') }}
                        </td>

                        <td>
                            Rp {{ number_format($penggajian->potongan,0,',','.') }}
                        </td>

                        <td>
                            Rp {{ number_format($penggajian->total_gaji,0,',','.') }}
                        </td>

                        <td>

                            @if($penggajian->potongan > 0)

                                <span class="badge bg-danger">
                                    Ada Potongan
                                </span>

                            @else

                                <span class="badge bg-success">
                                    Tidak Ada Potongan
                                </span>

                            @endif

                        </td>

                        <td>

                            <a
                                href="/penggajian/{{ $penggajian->id }}/edit"
                                class="btn btn-warning btn-sm"
                            >
                                Edit
                            </a>

                            <form
                                action="/penggajian/{{ $penggajian->id }}"
                                method="POST"
                                class="d-inline"
                            >

                                @csrf
                                @method('DELETE')

                                <button
                                    class="btn btn-danger btn-sm"
                                    onclick="return confirm('Yakin hapus?')"
                                >
                                    Hapus
                                </button>

                            </form>

                        </td>

                    </tr>

                    @empty

                    <tr>

                        <td colspan="10" class="text-center">
                            Data penggajian belum ada
                        </td>

                    </tr>

                    @endforelse

                </tbody>

            </table>

        </div>

    </div>

</div>

@endsection